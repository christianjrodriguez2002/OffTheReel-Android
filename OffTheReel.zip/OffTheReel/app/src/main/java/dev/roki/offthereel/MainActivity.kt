package dev.roki.offthereel

import android.Manifest
import android.app.DownloadManager
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import dev.roki.offthereel.ui.ArchiverScreen
import dev.roki.offthereel.ui.ArchiverTheme
import dev.roki.offthereel.ui.ScreenActions

class MainActivity : ComponentActivity() {

    private var storageOk by mutableStateOf(false)
    private var askStorage by mutableStateOf(false)

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { Engine.start(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        storageOk = Environment.isExternalStorageManager()

        val actions = ScreenActions(
            onDownload = { onDownloadPressed() },
            onOpenFolder = { openFolder() },
            onAllowStorage = { openStorageSettings() },
            onPlay = { play(it) }
        )

        setContent {
            ArchiverTheme {
                ArchiverScreen(
                    storageOk = storageOk,
                    askStorage = askStorage,
                    onDismissStorage = { askStorage = false },
                    actions = actions
                )
            }
        }

        handleShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) checkClipboard()
    }

    /**
     * Offer a YouTube link that's on the clipboard. Each copied item is only looked at once,
     * so Android's "pasted from your clipboard" notice doesn't keep popping up.
     */
    private fun checkClipboard() {
        try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val desc = cm.primaryClipDescription ?: return
            if (!desc.hasMimeType("text/*")) return
            val prefs = getSharedPreferences("archiver", MODE_PRIVATE)
            val stamp = desc.timestamp
            if (stamp != 0L && prefs.getLong("clipStamp", 0L) == stamp) return
            prefs.edit().putLong("clipStamp", stamp).apply()
            val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString() ?: return
            Engine.offerClip(text)
        } catch (_: Exception) {
        }
    }

    private fun play(entry: LibraryEntry) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", entry.file)
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(entry.file.extension.lowercase())
                ?: if (entry.audio) "audio/*" else "video/*"
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (_: Exception) {
            Toast.makeText(this, "No app on this phone can play that file.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        storageOk = Environment.isExternalStorageManager()
    }

    private fun handleShare(incoming: Intent?) {
        val shared = incoming ?: return
        if (shared.action != Intent.ACTION_SEND) return
        val text = shared.getStringExtra(Intent.EXTRA_TEXT) ?: return
        if (Engine.addLinks(text)) {
            Toast.makeText(this, "Added", Toast.LENGTH_SHORT).show()
        } else {
            Engine.setMessage("That doesn't look like a YouTube link.")
        }
        shared.action = null
    }

    private fun onDownloadPressed() {
        if (Engine.state.value.running) {
            Engine.stop()
            return
        }
        if (Engine.queue.value.isEmpty()) {
            Engine.setMessage("Paste a link in the box at the top first.")
            return
        }
        if (!Environment.isExternalStorageManager()) {
            askStorage = true
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        Engine.start(this)
    }

    private fun openStorageSettings() {
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
        }
    }

    private fun openFolder() {
        if (Environment.isExternalStorageManager()) Engine.saveDir().mkdirs()
        val uri = DocumentsContract.buildDocumentUri(
            "com.android.externalstorage.documents",
            "primary:Download/OffTheReel"
        )
        val folder = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, DocumentsContract.Document.MIME_TYPE_DIR)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(folder)
        } catch (_: Exception) {
            try {
                startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
            } catch (_: Exception) {
                Toast.makeText(this, "Open your Files app and go to Download/OffTheReel", Toast.LENGTH_LONG).show()
            }
        }
    }
}
