package dev.roki.offthereel

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Checks watched channels once a day, on Wi-Fi with enough battery, and downloads anything new.
 * Already-saved videos are skipped through archive.txt, so each check only grabs new uploads.
 */
class Watcher(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    companion object {
        private const val WORK = "watch-channels"
        private const val CHANNEL_ID = "downloads"
        private const val NOTIF_ID = 3

        /** Start the daily check when any channel is watched, stop it when none are. */
        fun sync(context: Context) {
            val wm = WorkManager.getInstance(context)
            if (Engine.watched.value.isEmpty()) {
                wm.cancelUniqueWork(WORK)
                return
            }
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.UNMETERED)
                .setRequiresBatteryNotLow(true)
                .build()
            val request = PeriodicWorkRequestBuilder<Watcher>(1, TimeUnit.DAYS)
                .setConstraints(constraints)
                .setInitialDelay(1, TimeUnit.HOURS)
                .build()
            wm.enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, request)
        }
    }

    override suspend fun doWork(): Result {
        if (Engine.watched.value.isEmpty()) return Result.success()
        if (!android.os.Environment.isExternalStorageManager()) return Result.success()
        try {
            setForeground(foregroundInfo("Checking watched channels"))
        } catch (_: Exception) {
            // Some phones block this while the app is in the background; the check still runs, just quieter.
        }
        val ran = Engine.runWatched(applicationContext)
        return if (ran) Result.success() else Result.retry()
    }

    override suspend fun getForegroundInfo(): ForegroundInfo = foregroundInfo("Checking watched channels")

    private fun foregroundInfo(text: String): ForegroundInfo {
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Downloads", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            applicationContext, 0,
            Intent(applicationContext, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle("OffTheReel")
            .setContentText(text)
            .setOngoing(true)
            .setSilent(true)
            .setProgress(0, 0, true)
            .setContentIntent(open)
            .build()
        return ForegroundInfo(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }
}
