@file:OptIn(ExperimentalTextApi::class)

package dev.roki.offthereel.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import dev.roki.offthereel.R

/** Black and orange: deep black deck, warm white text, orange record light. */
object Ink {
    val Oxide = Color(0xFF0A0A0A)
    val Deck = Color(0xFF161514)
    val Groove = Color(0xFF232120)
    val Seam = Color(0xFF363330)
    val Label = Color(0xFFF6F2EC)
    val Dust = Color(0xFFABA49C)
    val Faint = Color(0xFF6F6A64)
    val Signal = Color(0xFFFF7A1A)
    val SignalDeep = Color(0xFF3A1A05)
    val Rec = Color(0xFFFF4D3D)
    val Clean = Color(0xFF8FD18A)
    val Tape = Color(0xFFFFC266)
    val Rose = Color(0xFFF6F2EC)
}

private fun archivo(weight: Int, width: Float) = Font(
    R.font.archivo,
    weight = FontWeight(weight),
    variationSettings = FontVariation.Settings(
        FontVariation.weight(weight),
        FontVariation.width(width)
    )
)

/** Archivo at its normal width, for everything you read. */
val Archivo = FontFamily(
    archivo(400, 100f),
    archivo(500, 100f),
    archivo(600, 100f),
    archivo(700, 100f)
)

/** Archivo stretched to its widest, for the title and the reel. */
val ArchivoWide = FontFamily(
    archivo(800, 125f),
    archivo(900, 125f)
)

object Type {
    val Title = TextStyle(fontFamily = ArchivoWide, fontWeight = FontWeight(900), fontSize = 36.sp, lineHeight = 36.sp, letterSpacing = (-0.6).sp)
    val Reel = TextStyle(fontFamily = ArchivoWide, fontWeight = FontWeight(800), fontSize = 18.sp, lineHeight = 22.sp)
    val Pct = TextStyle(fontFamily = Archivo, fontWeight = FontWeight(600), fontSize = 13.sp, lineHeight = 16.sp, fontFeatureSettings = "tnum")
    val Body = TextStyle(fontFamily = Archivo, fontWeight = FontWeight(400), fontSize = 15.sp, lineHeight = 22.sp)
    val Strong = TextStyle(fontFamily = Archivo, fontWeight = FontWeight(600), fontSize = 15.sp, lineHeight = 22.sp)
    val Small = TextStyle(fontFamily = Archivo, fontWeight = FontWeight(500), fontSize = 13.sp, lineHeight = 18.sp)
    val Tiny = TextStyle(fontFamily = Archivo, fontWeight = FontWeight(500), fontSize = 12.sp, lineHeight = 16.sp)
    val Log = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 10.5.sp, lineHeight = 15.sp)
}

@Composable
fun ArchiverTheme(content: @Composable () -> Unit) {
    val base = Typography()
    val typography = Typography(
        headlineSmall = base.headlineSmall.copy(fontFamily = ArchivoWide, fontWeight = FontWeight(800)),
        titleMedium = base.titleMedium.copy(fontFamily = Archivo),
        bodyLarge = base.bodyLarge.copy(fontFamily = Archivo),
        bodyMedium = base.bodyMedium.copy(fontFamily = Archivo),
        bodySmall = base.bodySmall.copy(fontFamily = Archivo),
        labelLarge = base.labelLarge.copy(fontFamily = Archivo, fontWeight = FontWeight(600)),
        labelMedium = base.labelMedium.copy(fontFamily = Archivo)
    )
    val colors = darkColorScheme(
        primary = Ink.Signal,
        onPrimary = Ink.Oxide,
        primaryContainer = Ink.SignalDeep,
        onPrimaryContainer = Ink.Signal,
        secondary = Ink.Dust,
        background = Ink.Oxide,
        onBackground = Ink.Label,
        surface = Ink.Deck,
        onSurface = Ink.Label,
        surfaceVariant = Ink.Groove,
        onSurfaceVariant = Ink.Dust,
        surfaceContainer = Ink.Groove,
        surfaceContainerHigh = Ink.Deck,
        surfaceContainerHighest = Ink.Groove,
        outline = Ink.Seam,
        error = Ink.Rec
    )
    MaterialTheme(colorScheme = colors, typography = typography, content = content)
}
