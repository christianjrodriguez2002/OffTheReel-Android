package dev.roki.offthereel.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp

/**
 * The Download button, drawn as a tape reel.
 * The outer ring fills with progress and the hub windows turn while it records.
 * progress: 0..100, or below 0 while waiting with no percentage.
 */
@Composable
fun Reel(
    progress: Int,
    running: Boolean,
    enabled: Boolean,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val haptics = LocalHapticFeedback.current
    val target = if (progress < 0) 0f else progress / 100f
    val shown by animateFloatAsState(targetValue = target, animationSpec = tween(450), label = "progress")
    val spin = if (running) spinAngle(if (progress < 0) 2400 else 5200) else 0f
    val ringColor = if (running) Ink.Signal else Ink.Label

    Box(
        modifier = modifier
            .size(232.dp)
            .alpha(if (enabled) 1f else 0.45f)
            .clip(CircleShape)
            .clickable(enabled = enabled, role = Role.Button) {
                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f
            val c = Offset(size.width / 2f, size.height / 2f)
            val track = 9.dp.toPx()
            val ringR = r - track / 2f - 2.dp.toPx()

            // Outer track and progress
            val trackColor = if (!running && enabled) Ink.SignalDeep else Ink.Deck
            drawCircle(color = trackColor, radius = ringR, center = c, style = Stroke(width = track))
            if (running && progress < 0) {
                drawArc(
                    color = Ink.Signal,
                    startAngle = spin * 2f - 90f,
                    sweepAngle = 70f,
                    useCenter = false,
                    topLeft = Offset(c.x - ringR, c.y - ringR),
                    size = Size(ringR * 2f, ringR * 2f),
                    style = Stroke(width = track, cap = StrokeCap.Round)
                )
            } else if (shown > 0f) {
                drawArc(
                    color = Ink.Signal,
                    startAngle = -90f,
                    sweepAngle = 360f * shown,
                    useCenter = false,
                    topLeft = Offset(c.x - ringR, c.y - ringR),
                    size = Size(ringR * 2f, ringR * 2f),
                    style = Stroke(width = track, cap = StrokeCap.Round)
                )
            }

            // Reel body
            val bodyR = ringR - track - 6.dp.toPx()
            drawCircle(color = Ink.Groove, radius = bodyR, center = c)
            drawCircle(color = ringColor.copy(alpha = 0.18f), radius = bodyR, center = c, style = Stroke(width = 1.5.dp.toPx()))

            // Three windows cut into the reel, turning while it records
            val windowR = bodyR * 0.79f
            val windowW = bodyR * 0.17f
            rotate(degrees = spin, pivot = c) {
                for (i in 0 until 3) {
                    drawArc(
                        color = Ink.Oxide,
                        startAngle = -90f + i * 120f - 32f,
                        sweepAngle = 64f,
                        useCenter = false,
                        topLeft = Offset(c.x - windowR, c.y - windowR),
                        size = Size(windowR * 2f, windowR * 2f),
                        style = Stroke(width = windowW, cap = StrokeCap.Round)
                    )
                }
            }

            // Hub plate for the label
            drawCircle(color = Ink.Deck, radius = bodyR * 0.6f, center = c)
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, style = Type.Reel, color = if (running) Ink.Signal else Ink.Label)
            if (running && progress >= 0) {
                Text("$progress%", style = Type.Pct, color = Ink.Dust)
            }
        }
    }
}

@Composable
private fun spinAngle(durationMs: Int): Float {
    val transition = rememberInfiniteTransition(label = "spin")
    val angle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(durationMs, easing = LinearEasing), RepeatMode.Restart),
        label = "angle"
    )
    return angle
}
