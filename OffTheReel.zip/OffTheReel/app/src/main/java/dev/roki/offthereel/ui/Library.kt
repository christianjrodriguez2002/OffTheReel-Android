package dev.roki.offthereel.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.add
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.roki.offthereel.Engine
import dev.roki.offthereel.LibraryEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date
import java.util.Locale

/** Everything you've saved, newest first, plus the channels being watched. */
@Composable
fun LibraryScreen(
    watched: Set<String>,
    onBack: () -> Unit,
    onPlay: (LibraryEntry) -> Unit,
    onUnwatch: (String) -> Unit
) {
    val state by Engine.state.collectAsStateWithLifecycle()
    var entries by remember { mutableStateOf<List<LibraryEntry>?>(null) }
    var search by rememberSaveable { mutableStateOf("") }

    // Load on open, and again whenever a download finishes.
    LaunchedEffect(state.running) {
        if (!state.running) entries = withContext(Dispatchers.IO) { Engine.library() }
    }

    val all = entries
    val shown = if (all == null || search.isBlank()) all else {
        val q = search.trim().lowercase(Locale.getDefault())
        all.filter { it.title.lowercase(Locale.getDefault()).contains(q) || it.channel.lowercase(Locale.getDefault()).contains(q) }
    }

    val padding = WindowInsets.systemBars
        .add(WindowInsets(left = 20.dp, top = 8.dp, right = 20.dp, bottom = 32.dp))
        .asPaddingValues()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Ink.Oxide)
            .imePadding(),
        contentPadding = padding
    ) {
        item(key = "header") {
            Row(
                modifier = Modifier.padding(top = 12.dp, bottom = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Ink.Label)
                }
                Text("Library", style = Type.Title, color = Ink.Label, modifier = Modifier.padding(start = 4.dp))
            }
        }

        if (watched.isNotEmpty()) {
            item(key = "watchingLabel") {
                SectionLabel("Watching", "Checked once a day on Wi-Fi")
            }
            items(watched.sorted(), key = { "w:$it" }) { url ->
                WatchedRow(url = url, onStop = { onUnwatch(url) })
            }
        }

        item(key = "savedLabel") {
            SectionLabel("Saved", all?.let { if (it.isEmpty()) "" else "${it.size}" } ?: "")
        }

        if (all != null && all.size > 8) {
            item(key = "search") {
                SearchBox(value = search, onValueChange = { search = it })
            }
        }

        when {
            all == null -> item(key = "loading") {
                Text("Loading...", style = Type.Small, color = Ink.Dust, modifier = Modifier.padding(vertical = 12.dp))
            }
            all.isEmpty() -> item(key = "empty") {
                Text(
                    "Nothing saved yet.",
                    style = Type.Small,
                    color = Ink.Dust,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
            shown.isNullOrEmpty() -> item(key = "nomatch") {
                Text("No matches.", style = Type.Small, color = Ink.Dust, modifier = Modifier.padding(vertical = 12.dp))
            }
            else -> items(shown, key = { it.file.absolutePath }) { entry ->
                SavedRow(entry = entry, onClick = { onPlay(entry) })
            }
        }
    }
}

@Composable
private fun SectionLabel(title: String, note: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 18.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = Type.Strong, color = Ink.Label, modifier = Modifier.weight(1f))
        if (note.isNotEmpty()) Text(note, style = Type.Tiny, color = Ink.Faint)
    }
}

@Composable
private fun WatchedRow(url: String, onStop: () -> Unit) {
    Row(
        modifier = Modifier
            .padding(top = 8.dp)
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .clip(RoundedCornerShape(6.dp))
            .background(Ink.Deck),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .width(5.dp)
                .fillMaxHeight()
                .background(Kind.Channel.color)
        )
        Text(
            pretty(url),
            style = Type.Body,
            color = Ink.Label,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .weight(1f)
                .padding(start = 14.dp, top = 14.dp, bottom = 14.dp)
        )
        TextButton(onClick = onStop) {
            Text("Stop", style = Type.Strong, color = Ink.Dust)
        }
    }
}

@Composable
private fun SavedRow(entry: LibraryEntry, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .padding(top = 8.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Ink.Deck)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(21.dp))
                .background(Ink.Groove),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Filled.PlayArrow,
                contentDescription = null,
                tint = if (entry.audio) Ink.Tape else Ink.Signal,
                modifier = Modifier.size(22.dp)
            )
        }
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(start = 14.dp)
        ) {
            Text(entry.title, style = Type.Body, color = Ink.Label, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                listOf(entry.channel, sizeText(entry.size), dateText(entry.modified))
                    .filter { it.isNotEmpty() }
                    .joinToString("   "),
                style = Type.Tiny,
                color = Ink.Faint,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
private fun SearchBox(value: String, onValueChange: (String) -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = Type.Body.copy(color = Ink.Label),
        cursorBrush = SolidColor(Ink.Signal),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        modifier = Modifier
            .padding(bottom = 4.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(Ink.Deck)
            .border(1.dp, Ink.Seam, shape)
            .padding(horizontal = 16.dp, vertical = 13.dp),
        decorationBox = { inner ->
            Box {
                if (value.isEmpty()) Text("Search your library", style = Type.Body, color = Ink.Faint)
                inner()
            }
        }
    )
}

private fun sizeText(bytes: Long): String = when {
    bytes >= 1L shl 30 -> String.format(Locale.US, "%.1f GB", bytes / (1L shl 30).toDouble())
    bytes >= 1L shl 20 -> String.format(Locale.US, "%.0f MB", bytes / (1L shl 20).toDouble())
    bytes > 0 -> String.format(Locale.US, "%.0f KB", bytes / 1024.0)
    else -> ""
}

private fun dateText(millis: Long): String =
    DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(millis))
