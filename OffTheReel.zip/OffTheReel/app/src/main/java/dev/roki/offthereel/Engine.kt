package dev.roki.offthereel

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.MediaScannerConnection
import android.os.Environment
import androidx.core.content.ContextCompat
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLException
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File
import java.util.UUID

data class UiState(
    val ready: Boolean = false,
    val running: Boolean = false,
    val status: String = "Getting ready...",
    val progress: Int = -1,
    val logVersion: Int = 0,
    val done: Boolean = false
)

data class QueueItem(val url: String, val extras: Boolean)

object Engine {

    private const val DAY_MS = 24L * 60 * 60 * 1000
    private const val LOG_LIMIT = 200_000
    private val mediaExtensions = setOf("mp4", "mkv", "webm", "mp3", "m4a", "opus")

    // Channel > download date and title
    private const val BASE = "%(uploader)s/%(epoch>%Y-%m-%d)s - %(title).80s"

    val state = MutableStateFlow(UiState())
    val queue = MutableStateFlow<List<QueueItem>>(emptyList())

    private lateinit var prefs: SharedPreferences
    private val log = StringBuilder()

    @Volatile private var initialized = false
    @Volatile private var processId: String? = null
    @Volatile private var stopped = false

    private var itemText = ""
    private var skipped = 0
    private var failed = 0
    private var badLink = 0
    private var botBlock = false

    var audioOnly: Boolean
        get() = prefs.getBoolean("audio", false)
        set(value) { prefs.edit().putBoolean("audio", value).apply() }

    /** Whether newly added links save extras. Off by default. */
    var extrasDefault: Boolean
        get() = prefs.getBoolean("extrasDefault", false)
        set(value) { prefs.edit().putBoolean("extrasDefault", value).apply() }

    fun saveDir(): File =
        File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "OffTheReel")

    fun load(context: Context) {
        prefs = context.getSharedPreferences("archiver", Context.MODE_PRIVATE)
        val saved = prefs.getString("queue", "") ?: ""
        queue.value = saved.split("\n").filter { it.isNotBlank() }.map { line ->
            val tab = line.indexOf('\t')
            if (tab > 0) QueueItem(line.substring(tab + 1), line.substring(0, tab) == "1")
            else QueueItem(line, false)
        }
    }

    // ---------- Setup ----------

    fun setup(context: Context) {
        if (initialized) return
        setState { it.copy(ready = false, status = "Getting ready...", progress = -1) }
        try {
            YoutubeDL.getInstance().init(context)
            FFmpeg.getInstance().init(context)
        } catch (e: Exception) {
            appendLog(e.toString())
            setState { it.copy(status = "Couldn't start. Close the app and open it again.", progress = 0) }
            return
        }
        initialized = true

        val last = prefs.getLong("lastUpdate", 0L)
        if (System.currentTimeMillis() - last > DAY_MS) {
            setState { it.copy(status = "Checking for updates...") }
            try {
                YoutubeDL.getInstance().updateYoutubeDL(context)
                prefs.edit().putLong("lastUpdate", System.currentTimeMillis()).apply()
            } catch (e: Exception) {
                appendLog("Update check failed: ${e.message}")
            }
        }
        setState { it.copy(ready = true, progress = 0, status = readyText()) }
    }

    private fun readyText(): String =
        if (queue.value.isEmpty()) "Ready. Paste a link or share one from YouTube."
        else "Ready. Add more links or press Download."

    // ---------- Queue ----------

    /** Returns true if at least one link was added. */
    fun addLinks(text: String): Boolean {
        val current = queue.value.toMutableList()
        val extras = extrasDefault
        var added = false
        for (raw in text.split(Regex("\\s+"))) {
            var u = raw.trim().trim('"', '\'', '<', '>', '(', ')')
            if (u.isEmpty()) continue
            if (!u.startsWith("http://") && !u.startsWith("https://") &&
                Regex("^(www\\.|m\\.|music\\.)?(youtube\\.com|youtu\\.be)/.*").matches(u)
            ) {
                u = "https://$u"
            }
            if (!u.startsWith("http://") && !u.startsWith("https://")) continue
            if (current.none { it.url == u }) current.add(QueueItem(u, extras))
            added = true
        }
        if (added) {
            saveQueue(current)
            if (!state.value.running && state.value.ready) setState { it.copy(status = readyText(), done = false) }
        }
        return added
    }

    fun removeAt(index: Int) {
        val current = queue.value.toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            saveQueue(current)
        }
    }

    fun setExtras(index: Int, value: Boolean) {
        val current = queue.value.toMutableList()
        if (index in current.indices && current[index].extras != value) {
            current[index] = current[index].copy(extras = value)
            saveQueue(current)
        }
    }

    private fun saveQueue(list: List<QueueItem>) {
        queue.value = list
        val text = list.joinToString("\n") { (if (it.extras) "1" else "0") + "\t" + it.url }
        prefs.edit().putString("queue", text).apply()
    }

    fun setMessage(text: String) {
        setState { it.copy(status = text) }
    }

    // ---------- Download ----------

    fun start(context: Context) {
        if (state.value.running || !initialized || queue.value.isEmpty()) return
        setState { it.copy(running = true, done = false, progress = 0, status = "Starting...") }
        ContextCompat.startForegroundService(context, Intent(context, DownloadService::class.java))
    }

    fun stop() {
        stopped = true
        setState { it.copy(status = "Stopping...") }
        processId?.let { YoutubeDL.getInstance().destroyProcessById(it) }
    }

    /** Blocking. Called by DownloadService on a background thread. */
    fun runDownload(context: Context) {
        val items = queue.value.toList()
        if (items.isEmpty() || !initialized) {
            setState { it.copy(running = false) }
            return
        }

        stopped = false
        skipped = 0
        failed = 0
        badLink = 0
        botBlock = false
        clearLog()
        setState { it.copy(running = true, done = false, progress = 0, status = "Starting...") }

        val dir = saveDir()
        if (!dir.exists() && !dir.mkdirs()) {
            setState { it.copy(running = false, status = "Can't save to the Download folder. Check storage access.") }
            return
        }
        val startTime = System.currentTimeMillis()
        val audio = audioOnly
        var exitedClean = true

        // One run per link, so each link can have its own extras setting
        for (item in items) {
            if (stopped || botBlock) break
            itemText = ""
            val request = buildRequest(context, item, dir, audio)
            val id = UUID.randomUUID().toString()
            processId = id
            try {
                YoutubeDL.getInstance().execute(request, id, true) { _, _, line -> onLine(line) }
            } catch (e: YoutubeDL.CanceledException) {
                stopped = true
            } catch (e: YoutubeDLException) {
                exitedClean = false
                val msg = e.message
                if (!msg.isNullOrBlank()) appendLog(msg)
            } catch (e: Exception) {
                exitedClean = false
                appendLog(e.toString())
            }
            processId = null
        }

        tidyExtras(dir, startTime)
        scanNewFiles(context, dir, startTime)
        finish(exitedClean)
    }

    private fun buildRequest(context: Context, item: QueueItem, dir: File, audio: Boolean): YoutubeDLRequest {
        val request = YoutubeDLRequest(item.url)
        request.addOption("-P", dir.absolutePath)
        request.addOption("--download-archive", File(dir, "archive.txt").absolutePath)
        request.addOption("--cache-dir", File(context.cacheDir, "yt-dlp").absolutePath)
        request.addOption("--remote-components", "ejs:github")
        request.addOption("--newline")
        request.addOption("--no-mtime")
        request.addOption("--ignore-errors")
        request.addOption("--no-overwrites")
        request.addOption("--continue")
        request.addOption("--windows-filenames")
        request.addOption("--no-write-playlist-metafiles")
        request.addOption("--retries", 10)
        request.addOption("--fragment-retries", 10)
        request.addOption("--concurrent-fragments", 4)
        request.addOption("--sleep-interval", 5)
        request.addOption("--max-sleep-interval", 15)
        request.addOption("--sleep-requests", 1)
        request.addOption("--embed-metadata")
        request.addOption("--embed-thumbnail")
        request.addOption("--embed-chapters")

        if (item.extras) {
            // Folder per video, extras in their own folders
            request.addOption("-o", "$BASE/%(title).80s.%(ext)s")
            request.addOption("-o", "thumbnail:$BASE/Thumbnail/%(title).80s.%(ext)s")
            request.addOption("-o", "description:$BASE/Description/%(title).80s.%(ext)s")
            request.addOption("-o", "subtitle:$BASE/Subtitles/%(title).80s.%(ext)s")
            request.addOption("-o", "infojson:$BASE/Info/%(title).80s.%(ext)s")
            request.addOption("--write-thumbnail")
            request.addOption("--convert-thumbnails", "jpg")
            request.addOption("--write-description")
            request.addOption("--write-info-json")
            if (!audio) {
                request.addOption("--write-subs")
                request.addOption("--write-auto-subs")
            }
        } else {
            // Just the file, straight into the channel folder
            request.addOption("-o", "$BASE.%(ext)s")
        }

        if (audio) {
            request.addOption("-f", "ba/b")
            request.addOption("-x")
            request.addOption("--audio-format", "mp3")
            request.addOption("--audio-quality", "0")
        } else {
            request.addOption("-f", "bv*+ba/b")
            request.addOption("--merge-output-format", "mp4")
            request.addOption("--embed-subs")
            request.addOption("--sub-langs", "en")
        }
        return request
    }

    private val progressRegex = Regex("^\\[download\\]\\s+([\\d.]+)%")
    private val itemRegex = Regex("Downloading item (\\d+) of (\\d+)")
    private val destRegex = Regex("^\\[download\\] Destination: (.+)$")

    private fun onLine(line: String) {
        val p = progressRegex.find(line)
        if (p != null) {
            val pct = p.groupValues[1].toDoubleOrNull()?.toInt()?.coerceIn(0, 100) ?: 0
            setState { it.copy(progress = pct) }
            if (!line.contains(" in ")) return
        } else {
            val item = itemRegex.find(line)
            val dest = destRegex.find(line)
            when {
                item != null -> itemText = "Video ${item.groupValues[1]} of ${item.groupValues[2]}"
                dest != null -> {
                    var name = File(dest.groupValues[1]).name
                    name = name.replace(Regex("\\.f\\d+\\.\\w+$"), "").replace(Regex("\\.\\w+$"), "")
                    name = name.replace(Regex("^\\d{4}-\\d{2}-\\d{2} - "), "")
                    val text = if (itemText.isEmpty()) name else itemText + "\n" + name
                    setState { it.copy(status = text) }
                }
                line.contains("has already been recorded in the archive") -> skipped++
                line.startsWith("ERROR") -> {
                    when {
                        Regex("confirm you.re not a bot|HTTP Error 429").containsMatchIn(line) -> botBlock = true
                        Regex("Unsupported URL|is not a valid URL|Incomplete YouTube ID|does not exist|HTTP Error 404")
                            .containsMatchIn(line) -> badLink++
                        else -> failed++
                    }
                }
            }
        }
        appendLog(line)
    }

    private fun finish(exitedClean: Boolean) {
        val message: String
        var clearQueue = false
        when {
            stopped -> message = "Stopped. Press Download to continue where it left off."
            botBlock -> message = "YouTube is limiting downloads. Wait an hour or so, then press Download again."
            badLink > 0 -> message = "One of the links didn't work. Check it and try again."
            !exitedClean && failed == 0 -> message = "Something went wrong. Tap Show details to see why."
            else -> {
                var m = "Done!"
                if (failed > 0) m += " $failed video(s) couldn't be saved (private or removed)."
                else if (skipped > 0) m += " ($skipped were already saved)"
                message = m
                clearQueue = true
            }
        }
        if (clearQueue) saveQueue(emptyList())
        setState {
            it.copy(
                running = false,
                done = clearQueue,
                progress = if (clearQueue) 100 else it.progress,
                status = message
            )
        }
    }

    /** Descriptions become .txt so the phone can open them, and thumbnails stay out of the Gallery. */
    private fun tidyExtras(dir: File, since: Long) {
        try {
            dir.walkTopDown()
                .filter { it.lastModified() >= since - 5000 }
                .toList()
                .forEach { f ->
                    if (f.isFile && f.extension == "description") {
                        val txt = File(f.parentFile, f.nameWithoutExtension + ".txt")
                        if (!txt.exists()) f.renameTo(txt)
                    } else if (f.isDirectory && f.name == "Thumbnail") {
                        val marker = File(f, ".nomedia")
                        if (!marker.exists()) marker.createNewFile()
                    }
                }
        } catch (_: Exception) {
        }
    }

    private fun scanNewFiles(context: Context, dir: File, since: Long) {
        try {
            val paths = dir.walkTopDown()
                .filter { it.isFile && it.lastModified() >= since - 5000 && it.extension.lowercase() in mediaExtensions }
                .map { it.absolutePath }
                .toList()
            if (paths.isNotEmpty()) {
                MediaScannerConnection.scanFile(context, paths.toTypedArray(), null, null)
            }
        } catch (_: Exception) {
        }
    }

    // ---------- Log ----------

    fun logText(): String = synchronized(log) {
        if (log.length > 40_000) log.substring(log.length - 40_000) else log.toString()
    }

    private fun appendLog(line: String) {
        synchronized(log) {
            log.append(line).append('\n')
            if (log.length > LOG_LIMIT) log.delete(0, log.length - LOG_LIMIT / 2)
        }
        setState { it.copy(logVersion = it.logVersion + 1) }
    }

    private fun clearLog() {
        synchronized(log) { log.setLength(0) }
        setState { it.copy(logVersion = it.logVersion + 1) }
    }

    @Synchronized
    private fun setState(change: (UiState) -> UiState) {
        state.value = change(state.value)
    }
}
