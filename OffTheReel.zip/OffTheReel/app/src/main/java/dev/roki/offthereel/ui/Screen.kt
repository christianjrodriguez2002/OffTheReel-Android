package dev.roki.offthereel.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.add
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.roki.offthereel.Engine
import dev.roki.offthereel.LibraryEntry
import dev.roki.offthereel.QUALITIES
import dev.roki.offthereel.QueueItem
import dev.roki.offthereel.R
import dev.roki.offthereel.Update
import dev.roki.offthereel.UpdateDownload
import dev.roki.offthereel.Updates
import kotlinx.coroutines.launch

class ScreenActions(
    val onDownload: () -> Unit,
    val onOpenFolder: () -> Unit,
    val onAllowStorage: () -> Unit,
    val onPlay: (LibraryEntry) -> Unit
)

private const val NOT_A_LINK = "That doesn't look like a YouTube link."

@Composable
fun ArchiverScreen(
    storageOk: Boolean,
    askStorage: Boolean,
    onDismissStorage: () -> Unit,
    actions: ScreenActions
) {
    val state by Engine.state.collectAsStateWithLifecycle()
    val queue by Engine.queue.collectAsStateWithLifecycle()
    var input by rememberSaveable { mutableStateOf("") }
    var detailsOpen by rememberSaveable { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var audio by remember { mutableStateOf(Engine.audioOnly) }
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val locked = state.running
    var update by remember { mutableStateOf<Update?>(null) }
    LaunchedEffect(Unit) { update = Updates.check(context) }
    val clip by Engine.clipOffer.collectAsStateWithLifecycle()
    val watched by Engine.watched.collectAsStateWithLifecycle()
    var quality by remember { mutableStateOf(Engine.quality) }
    var screen by rememberSaveable { mutableStateOf("main") }

    fun addInput() {
        if (input.isBlank()) return
        if (Engine.addLinks(input)) input = "" else Engine.setMessage(NOT_A_LINK)
    }

    fun paste() {
        val text = clipboard.getText()?.text
        if (text.isNullOrBlank()) {
            Engine.setMessage("Your clipboard is empty. Copy a link first.")
        } else if (!Engine.addLinks(text)) {
            input = text
            Engine.setMessage(NOT_A_LINK)
        }
    }

    val padding = WindowInsets.systemBars
        .add(WindowInsets(left = 20.dp, top = 8.dp, right = 20.dp, bottom = 32.dp))
        .asPaddingValues()

    if (screen == "library") {
        BackHandler { screen = "main" }
        LibraryScreen(
            watched = watched,
            onBack = { screen = "main" },
            onPlay = actions.onPlay,
            onUnwatch = { Engine.setWatched(context, it, false) }
        )
    } else LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Ink.Oxide)
            .imePadding(),
        contentPadding = padding
    ) {
        item(key = "header") {
            Header(onSettings = { settingsOpen = true }, onLibrary = { screen = "library" })
        }

        update?.let { u ->
            item(key = "update") {
                UpdateBanner(
                    u = u,
                    onLater = {
                        Updates.skip(context, u)
                        update = null
                    }
                )
            }
        }

        clip?.let { link ->
            item(key = "clip") {
                ClipOffer(
                    link = link,
                    onAdd = { Engine.answerClip(add = true) },
                    onDismiss = { Engine.answerClip(add = false) }
                )
            }
        }

        if (!storageOk) {
            item(key = "storage") {
                StorageBanner(onAllow = actions.onAllowStorage)
            }
        }

        item(key = "input") {
            LinkInput(
                value = input,
                enabled = !locked,
                onValueChange = { input = it },
                onAdd = { addInput() },
                onPaste = { paste() }
            )
        }

        itemsIndexed(queue, key = { _, item -> item.url }) { index, item ->
            SpineRow(
                item = item,
                locked = locked,
                watched = watched.contains(item.url),
                onExtras = { Engine.setExtras(index, it) },
                onWatch = { Engine.setWatched(context, item.url, it) },
                onRemove = { Engine.removeAt(index) },
                modifier = Modifier.animateItem()
            )
        }

        item(key = "reel") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Reel(
                    progress = when {
                        state.running -> state.progress
                        state.done -> 100
                        else -> 0
                    },
                    running = state.running,
                    enabled = state.ready || state.running,
                    label = if (state.running) "Stop" else "Download",
                    onClick = {
                        if (!state.running && input.isNotBlank()) addInput()
                        actions.onDownload()
                    }
                )
                val statusColor by animateColorAsState(
                    targetValue = if (state.done) Ink.Clean else Ink.Dust,
                    animationSpec = tween(300),
                    label = "status"
                )
                Text(
                    text = state.status,
                    style = Type.Small,
                    color = statusColor,
                    textAlign = TextAlign.Center,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 18.dp, start = 12.dp, end = 12.dp)
                )
            }
        }

        item(key = "format") {
            Column(modifier = Modifier.padding(top = 32.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Ink.Deck)
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Segment("Video", selected = !audio, enabled = !locked, modifier = Modifier.weight(1f)) {
                        audio = false
                        Engine.audioOnly = false
                    }
                    Segment("Audio only (MP3)", selected = audio, enabled = !locked, modifier = Modifier.weight(1f)) {
                        audio = true
                        Engine.audioOnly = true
                    }
                }
                AnimatedVisibility(
                    visible = !audio,
                    enter = expandVertically(tween(220)) + fadeIn(tween(180)),
                    exit = shrinkVertically(tween(200)) + fadeOut(tween(120))
                ) {
                    QualityRow(quality = quality, enabled = !locked) {
                        quality = it
                        Engine.quality = it
                    }
                }
            }
        }

        item(key = "save") {
            SaveRow(onOpen = actions.onOpenFolder)
        }

        item(key = "details") {
            Details(
                open = detailsOpen,
                logVersion = state.logVersion,
                onToggle = { detailsOpen = !detailsOpen }
            )
        }
    }

    if (settingsOpen) {
        SettingsDialog(
            onClose = { settingsOpen = false },
            onFound = { update = it }
        )
    }

    if (askStorage) {
        AlertDialog(
            onDismissRequest = onDismissStorage,
            containerColor = Ink.Deck,
            title = { Text("Allow storage access", color = Ink.Label) },
            text = {
                Text(
                    "Videos are saved to your Download folder. Turn on access for OffTheReel on the next screen, then come back and press Download.",
                    style = Type.Body,
                    color = Ink.Dust
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onDismissStorage()
                    actions.onAllowStorage()
                }) { Text("Continue", style = Type.Strong, color = Ink.Signal) }
            },
            dismissButton = {
                TextButton(onClick = onDismissStorage) { Text("Cancel", style = Type.Strong, color = Ink.Dust) }
            }
        )
    }
}

@Composable
private fun Header(onSettings: () -> Unit, onLibrary: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 20.dp, bottom = 24.dp),
        verticalAlignment = Alignment.Top
    ) {
        FitTitle(
            text = "OffTheReel",
            modifier = Modifier
                .weight(1f)
                .padding(end = 4.dp)
        )
        IconButton(onClick = onLibrary) {
            Icon(
                painter = painterResource(R.drawable.ic_library),
                contentDescription = "Library",
                tint = Ink.Dust,
                modifier = Modifier.size(22.dp)
            )
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "More", tint = Ink.Dust)
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Settings", style = Type.Body, color = Ink.Label) },
                    onClick = {
                        menu = false
                        onSettings()
                    }
                )
            }
        }
    }
}

@Composable
private fun StorageBanner(onAllow: () -> Unit) {
    Row(
        modifier = Modifier
            .padding(bottom = 14.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Ink.SignalDeep)
            .padding(start = 16.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "Allow storage access so videos can be saved.",
            style = Type.Small,
            color = Ink.Label,
            modifier = Modifier.weight(1f)
        )
        TextButton(onClick = onAllow) {
            Text("Allow", style = Type.Strong, color = Ink.Signal)
        }
    }
}

@Composable
private fun LinkInput(
    value: String,
    enabled: Boolean,
    onValueChange: (String) -> Unit,
    onAdd: () -> Unit,
    onPaste: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(14.dp)
    val edge by animateColorAsState(
        targetValue = if (focused) Ink.Signal else Ink.Seam,
        animationSpec = tween(200),
        label = "edge"
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Ink.Deck)
            .border(1.dp, edge, shape)
            .padding(start = 16.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            enabled = enabled,
            singleLine = true,
            textStyle = Type.Body.copy(color = Ink.Label),
            cursorBrush = SolidColor(Ink.Signal),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { onAdd() }),
            modifier = Modifier
                .weight(1f)
                .padding(vertical = 17.dp)
                .onFocusChanged { focused = it.isFocused },
            decorationBox = { inner ->
                Box {
                    if (value.isEmpty()) {
                        Text("Paste a YouTube link", style = Type.Body, color = Ink.Faint)
                    }
                    inner()
                }
            }
        )
        if (value.isBlank()) {
            IconButton(onClick = onPaste, enabled = enabled) {
                Icon(
                    painter = painterResource(R.drawable.ic_paste),
                    contentDescription = "Paste",
                    tint = Ink.Dust,
                    modifier = Modifier.size(22.dp)
                )
            }
        } else {
            TextButton(onClick = onAdd, enabled = enabled) {
                Text("Add", style = Type.Strong, color = Ink.Signal)
            }
        }
    }
}

internal enum class Kind(val label: String, val color: Color) {
    Video("Video", Ink.Signal),
    ShortVideo("Short", Ink.Rec),
    Playlist("Playlist", Ink.Tape),
    Channel("Channel", Ink.Rose)
}

internal fun kindOf(url: String): Kind = when (Engine.kindOf(url)) {
    "Short" -> Kind.ShortVideo
    "Playlist" -> Kind.Playlist
    "Channel" -> Kind.Channel
    else -> Kind.Video
}

internal fun pretty(url: String): String =
    url.removePrefix("https://").removePrefix("http://")
        .removePrefix("www.").removePrefix("m.")
        .replace(Regex("[?&]si=[^&]*"), "")
        .removeSuffix("?")

/** A queued link, drawn like the spine of a tape: the colored edge says what kind of link it is. */
@Composable
private fun SpineRow(
    item: QueueItem,
    locked: Boolean,
    watched: Boolean,
    onExtras: (Boolean) -> Unit,
    onWatch: (Boolean) -> Unit,
    onRemove: () -> Unit,
    modifier: Modifier = Modifier
) {
    val kind = kindOf(item.url)
    Row(
        modifier = modifier
            .padding(top = 8.dp)
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .clip(RoundedCornerShape(6.dp))
            .background(Ink.Deck),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .width(5.dp)
                .fillMaxHeight()
                .background(kind.color)
        )
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(start = 14.dp, top = 10.dp, bottom = 12.dp, end = 4.dp)
        ) {
            Text(kind.label, style = Type.Tiny, color = kind.color)
            Text(
                pretty(item.url),
                style = Type.Body,
                color = Ink.Label,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(
                modifier = Modifier.padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Chip("Extras", on = item.extras, enabled = !locked, onToggle = { onExtras(!item.extras) })
                if (kind == Kind.Channel) {
                    Chip(if (watched) "Watching" else "Watch", on = watched, enabled = true, onToggle = { onWatch(!watched) })
                }
            }
        }
        IconButton(onClick = onRemove, enabled = !locked, modifier = Modifier.padding(top = 4.dp)) {
            Icon(
                Icons.Filled.Close,
                contentDescription = "Remove",
                tint = if (locked) Ink.Seam else Ink.Faint,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun Chip(label: String, on: Boolean, enabled: Boolean, onToggle: () -> Unit) {
    val shape = RoundedCornerShape(50)
    val fill by animateColorAsState(if (on) Ink.SignalDeep else Color.Transparent, tween(200), label = "fill")
    val edge by animateColorAsState(if (on) Ink.Signal else Ink.Seam, tween(200), label = "chipEdge")
    val ink by animateColorAsState(if (on) Ink.Signal else Ink.Dust, tween(200), label = "chipInk")
    Box(
        modifier = Modifier
            .clip(shape)
            .background(fill)
            .border(1.dp, edge, shape)
            .clickable(enabled = enabled, onClick = onToggle)
            .padding(horizontal = 11.dp, vertical = 6.dp)
    ) {
        Text(label, style = Type.Tiny, color = ink)
    }
}

@Composable
private fun Segment(
    label: String,
    selected: Boolean,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val fill by animateColorAsState(if (selected) Ink.Groove else Color.Transparent, tween(220), label = "segment")
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(9.dp))
            .background(fill)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            style = if (selected) Type.Strong else Type.Body,
            color = if (selected) Ink.Label else Ink.Dust
        )
    }
}

@Composable
private fun SaveRow(onOpen: () -> Unit) {
    Row(
        modifier = Modifier
            .padding(top = 10.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Ink.Deck)
            .clickable(onClick = onOpen)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_folder),
            contentDescription = null,
            tint = Ink.Dust,
            modifier = Modifier.size(20.dp)
        )
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(start = 14.dp)
        ) {
            Text("Saves to", style = Type.Tiny, color = Ink.Faint)
            Text("Download/OffTheReel", style = Type.Body, color = Ink.Label)
        }
        Text("Open", style = Type.Strong, color = Ink.Signal)
    }
}

@Composable
private fun Details(open: Boolean, logVersion: Int, onToggle: () -> Unit) {
    Column(
        modifier = Modifier
            .padding(top = 20.dp)
            .fillMaxWidth()
    ) {
        Text(
            text = if (open) "Hide details" else "Show details",
            style = Type.Small,
            color = Ink.Dust,
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .clickable(onClick = onToggle)
                .padding(horizontal = 4.dp, vertical = 8.dp)
        )
        AnimatedVisibility(
            visible = open,
            enter = expandVertically(tween(260)) + fadeIn(tween(200)),
            exit = shrinkVertically(tween(220)) + fadeOut(tween(150))
        ) {
            Column {
                val logText = remember(logVersion) { Engine.logText() }
                val vertical = rememberScrollState()
                val horizontal = rememberScrollState()
                LaunchedEffect(logText) {
                    withFrameNanos { }
                    vertical.scrollTo(vertical.maxValue)
                }
                Box(
                    modifier = Modifier
                        .padding(top = 4.dp)
                        .fillMaxWidth()
                        .height(260.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Ink.Deck)
                        .verticalScroll(vertical)
                        .horizontalScroll(horizontal)
                        .padding(12.dp)
                ) {
                    Text(
                        text = logText.ifEmpty { "Nothing yet." },
                        style = Type.Log,
                        color = Ink.Dust,
                        softWrap = false
                    )
                }
                Text(
                    "Made by Roki Rodriguez on October 31st, 2026",
                    style = Type.Tiny,
                    color = Ink.Faint,
                    modifier = Modifier.padding(top = 12.dp, start = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun SettingsDialog(onClose: () -> Unit, onFound: (Update) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var extras by remember { mutableStateOf(Engine.extrasDefault) }
    var checking by remember { mutableStateOf(false) }
    var checkResult by remember { mutableStateOf<String?>(null) }
    fun update(value: Boolean) {
        extras = value
        Engine.extrasDefault = value
    }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Ink.Deck,
        title = { Text("Settings", color = Ink.Label) },
        text = {
            Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { update(!extras) }
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 12.dp)
                ) {
                    Text("Extras on new links", style = Type.Strong, color = Ink.Label)
                    Text("Thumbnail, description and subtitles", style = Type.Small, color = Ink.Dust)
                }
                Switch(
                    checked = extras,
                    onCheckedChange = { update(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Ink.Oxide,
                        checkedTrackColor = Ink.Signal,
                        uncheckedThumbColor = Ink.Dust,
                        uncheckedTrackColor = Ink.Groove,
                        uncheckedBorderColor = Ink.Seam
                    )
                )
            }
            Box(
                modifier = Modifier
                    .padding(vertical = 12.dp)
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Ink.Seam)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Version ${Updates.installed(context)}", style = Type.Strong, color = Ink.Label)
                    Text(
                        checkResult ?: "Made by Roki Rodriguez",
                        style = Type.Small,
                        color = Ink.Dust
                    )
                }
                TextButton(
                    enabled = !checking,
                    onClick = {
                        checking = true
                        checkResult = null
                        scope.launch {
                            val found = Updates.check(context, force = true)
                            checking = false
                            when {
                                found != null -> {
                                    onFound(found)
                                    onClose()
                                }
                                Updates.offline -> checkResult = "Couldn't reach GitHub. Check your connection."
                                else -> checkResult = "You have the latest version."
                            }
                        }
                    }
                ) {
                    Text(
                        if (checking) "Checking..." else "Check for updates",
                        style = Type.Strong,
                        color = if (checking) Ink.Dust else Ink.Signal
                    )
                }
            }
            }
        },
        confirmButton = {
            TextButton(onClick = onClose) { Text("Done", style = Type.Strong, color = Ink.Signal) }
        }
    )
}

@Composable
private fun UpdateBanner(u: Update, onLater: () -> Unit) {
    val context = LocalContext.current
    var open by remember(u.version) { mutableStateOf(false) }
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier = Modifier
            .padding(bottom = 14.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(Ink.Deck)
            .border(1.dp, Ink.Signal.copy(alpha = 0.55f), shape)
            .clickable(enabled = u.notes.isNotBlank()) { open = !open }
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(Ink.Signal)
            )
            Text(
                "OffTheReel ${u.version} is out",
                style = Type.Strong,
                color = Ink.Label,
                modifier = Modifier
                    .padding(start = 10.dp)
                    .weight(1f)
            )
            if (u.notes.isNotBlank()) {
                Text(if (open) "Hide" else "What's new", style = Type.Small, color = Ink.Dust)
            }
        }
        Text(
            "You have ${Updates.installed(context)}.",
            style = Type.Small,
            color = Ink.Dust,
            modifier = Modifier.padding(start = 18.dp, top = 2.dp)
        )
        AnimatedVisibility(
            visible = open,
            enter = expandVertically(tween(240)) + fadeIn(tween(200)),
            exit = shrinkVertically(tween(200)) + fadeOut(tween(150))
        ) {
            Text(
                u.notes,
                style = Type.Small,
                color = Ink.Label,
                modifier = Modifier.padding(start = 18.dp, top = 10.dp)
            )
        }

        Box(modifier = Modifier.padding(top = 14.dp)) {
            when (val dl = Updates.download.value) {
                is UpdateDownload.Running -> Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(Ink.Groove)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(dl.percent / 100f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(3.dp))
                                .background(Ink.Signal)
                        )
                    }
                    Text(
                        "Downloading ${dl.percent}%",
                        style = Type.Small,
                        color = Ink.Dust,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                is UpdateDownload.Done -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Install", primary = true) { Updates.install(context, dl.file) }
                    Pill("Later") { onLater() }
                }
                is UpdateDownload.Failed -> Column {
                    Text(dl.reason, style = Type.Small, color = Ink.Rec, modifier = Modifier.padding(bottom = 10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("Try again", primary = true) { Updates.start(context, u) }
                        Pill("Releases") { Updates.openReleases(context, u.pageUrl) }
                    }
                }
                UpdateDownload.Idle -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Download", primary = true) { Updates.start(context, u) }
                    Pill("Later") { onLater() }
                }
            }
        }
    }
}

@Composable
private fun Pill(label: String, primary: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (primary) Ink.Signal else Ink.Groove)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 9.dp)
    ) {
        Text(label, style = Type.Strong, color = if (primary) Ink.Oxide else Ink.Label)
    }
}

@Composable
private fun ClipOffer(link: String, onAdd: () -> Unit, onDismiss: () -> Unit) {
    Row(
        modifier = Modifier
            .padding(bottom = 12.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Ink.Deck)
            .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text("Copied link", style = Type.Tiny, color = Ink.Faint)
            Text(pretty(link), style = Type.Body, color = Ink.Label, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        TextButton(onClick = onAdd) {
            Text("Add", style = Type.Strong, color = Ink.Signal)
        }
        IconButton(onClick = onDismiss) {
            Icon(Icons.Filled.Close, contentDescription = "Dismiss", tint = Ink.Faint, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun QualityRow(quality: Int, enabled: Boolean, onPick: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val label = QUALITIES.firstOrNull { it.first == quality }?.second ?: "Best"
    Row(
        modifier = Modifier
            .padding(top = 8.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Ink.Deck)
            .clickable(enabled = enabled) { open = true }
            .padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Video quality", style = Type.Body, color = Ink.Dust, modifier = Modifier.weight(1f))
        Box {
            Text(
                "$label  \u25BE",
                style = Type.Strong,
                color = if (enabled) Ink.Label else Ink.Faint,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
            )
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                QUALITIES.forEach { (height, name) ->
                    DropdownMenuItem(
                        text = { Text(name, style = Type.Body, color = if (height == quality) Ink.Signal else Ink.Label) },
                        onClick = {
                            open = false
                            onPick(height)
                        }
                    )
                }
            }
        }
    }
}

/**
 * The title on one line at the biggest size that fits. It starts at the full title size and
 * steps down until nothing overflows, staying hidden until it fits so you never see it jump.
 */
@Composable
private fun FitTitle(text: String, modifier: Modifier = Modifier) {
    var size by remember { mutableStateOf(Type.Title.fontSize) }
    var ready by remember { mutableStateOf(false) }
    Text(
        text = text,
        style = Type.Title.copy(fontSize = size, lineHeight = size),
        color = Ink.Label,
        maxLines = 1,
        softWrap = false,
        modifier = modifier.drawWithContent { if (ready) drawContent() },
        onTextLayout = { result ->
            if (result.didOverflowWidth && size.value > 16f) {
                size = (size.value * 0.93f).sp
            } else {
                ready = true
            }
        }
    )
}
