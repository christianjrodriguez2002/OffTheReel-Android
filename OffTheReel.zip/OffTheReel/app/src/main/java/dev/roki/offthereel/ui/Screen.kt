package dev.roki.offthereel.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.add
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.roki.offthereel.Engine
import dev.roki.offthereel.QueueItem
import dev.roki.offthereel.R

class ScreenActions(
    val onDownload: () -> Unit,
    val onOpenFolder: () -> Unit,
    val onAllowStorage: () -> Unit
)

private const val NOT_A_LINK = "That doesn't look like a YouTube link."

@Composable
fun ArchiverScreen(
    storageOk: Boolean,
    askStorage: Boolean,
    onDismissStorage: () -> Unit,
    actions: ScreenActions
) {
    val state by Engine.state.collectAsStateWithLifecycle()
    val queue by Engine.queue.collectAsStateWithLifecycle()
    var input by rememberSaveable { mutableStateOf("") }
    var detailsOpen by rememberSaveable { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var audio by remember { mutableStateOf(Engine.audioOnly) }
    val clipboard = LocalClipboardManager.current
    val locked = state.running

    fun addInput() {
        if (input.isBlank()) return
        if (Engine.addLinks(input)) input = "" else Engine.setMessage(NOT_A_LINK)
    }

    fun paste() {
        val text = clipboard.getText()?.text
        if (text.isNullOrBlank()) {
            Engine.setMessage("Your clipboard is empty. Copy a link first.")
        } else if (!Engine.addLinks(text)) {
            input = text
            Engine.setMessage(NOT_A_LINK)
        }
    }

    val padding = WindowInsets.systemBars
        .add(WindowInsets(left = 20.dp, top = 8.dp, right = 20.dp, bottom = 32.dp))
        .asPaddingValues()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Ink.Oxide)
            .imePadding(),
        contentPadding = padding
    ) {
        item(key = "header") {
            Header(onSettings = { settingsOpen = true })
        }

        if (!storageOk) {
            item(key = "storage") {
                StorageBanner(onAllow = actions.onAllowStorage)
            }
        }

        item(key = "input") {
            LinkInput(
                value = input,
                enabled = !locked,
                onValueChange = { input = it },
                onAdd = { addInput() },
                onPaste = { paste() }
            )
        }

        itemsIndexed(queue, key = { _, item -> item.url }) { index, item ->
            SpineRow(
                item = item,
                locked = locked,
                onExtras = { Engine.setExtras(index, it) },
                onRemove = { Engine.removeAt(index) },
                modifier = Modifier.animateItem()
            )
        }

        item(key = "reel") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Reel(
                    progress = when {
                        state.running -> state.progress
                        state.done -> 100
                        else -> 0
                    },
                    running = state.running,
                    enabled = state.ready || state.running,
                    label = if (state.running) "Stop" else "Download",
                    onClick = {
                        if (!state.running && input.isNotBlank()) addInput()
                        actions.onDownload()
                    }
                )
                val statusColor by animateColorAsState(
                    targetValue = if (state.done) Ink.Clean else Ink.Dust,
                    animationSpec = tween(300),
                    label = "status"
                )
                Text(
                    text = state.status,
                    style = Type.Small,
                    color = statusColor,
                    textAlign = TextAlign.Center,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 18.dp, start = 12.dp, end = 12.dp)
                )
            }
        }

        item(key = "format") {
            Row(
                modifier = Modifier
                    .padding(top = 32.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Ink.Deck)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Segment("Video", selected = !audio, enabled = !locked, modifier = Modifier.weight(1f)) {
                    audio = false
                    Engine.audioOnly = false
                }
                Segment("Audio only (MP3)", selected = audio, enabled = !locked, modifier = Modifier.weight(1f)) {
                    audio = true
                    Engine.audioOnly = true
                }
            }
        }

        item(key = "save") {
            SaveRow(onOpen = actions.onOpenFolder)
        }

        item(key = "details") {
            Details(
                open = detailsOpen,
                logVersion = state.logVersion,
                onToggle = { detailsOpen = !detailsOpen }
            )
        }
    }

    if (settingsOpen) {
        SettingsDialog(onClose = { settingsOpen = false })
    }

    if (askStorage) {
        AlertDialog(
            onDismissRequest = onDismissStorage,
            containerColor = Ink.Deck,
            title = { Text("Allow storage access", color = Ink.Label) },
            text = {
                Text(
                    "Videos are saved to your Download folder. Turn on access for OffTheReel on the next screen, then come back and press Download.",
                    style = Type.Body,
                    color = Ink.Dust
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onDismissStorage()
                    actions.onAllowStorage()
                }) { Text("Continue", style = Type.Strong, color = Ink.Signal) }
            },
            dismissButton = {
                TextButton(onClick = onDismissStorage) { Text("Cancel", style = Type.Strong, color = Ink.Dust) }
            }
        )
    }
}

@Composable
private fun Header(onSettings: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 20.dp, bottom = 24.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = "OffTheReel",
            style = Type.Title,
            color = Ink.Label,
            modifier = Modifier.weight(1f)
        )
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "More", tint = Ink.Dust)
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Settings", style = Type.Body, color = Ink.Label) },
                    onClick = {
                        menu = false
                        onSettings()
                    }
                )
            }
        }
    }
}

@Composable
private fun StorageBanner(onAllow: () -> Unit) {
    Row(
        modifier = Modifier
            .padding(bottom = 14.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Ink.SignalDeep)
            .padding(start = 16.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "Allow storage access so videos can be saved.",
            style = Type.Small,
            color = Ink.Label,
            modifier = Modifier.weight(1f)
        )
        TextButton(onClick = onAllow) {
            Text("Allow", style = Type.Strong, color = Ink.Signal)
        }
    }
}

@Composable
private fun LinkInput(
    value: String,
    enabled: Boolean,
    onValueChange: (String) -> Unit,
    onAdd: () -> Unit,
    onPaste: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(14.dp)
    val edge by animateColorAsState(
        targetValue = if (focused) Ink.Signal else Ink.Seam,
        animationSpec = tween(200),
        label = "edge"
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Ink.Deck)
            .border(1.dp, edge, shape)
            .padding(start = 16.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            enabled = enabled,
            singleLine = true,
            textStyle = Type.Body.copy(color = Ink.Label),
            cursorBrush = SolidColor(Ink.Signal),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { onAdd() }),
            modifier = Modifier
                .weight(1f)
                .padding(vertical = 17.dp)
                .onFocusChanged { focused = it.isFocused },
            decorationBox = { inner ->
                Box {
                    if (value.isEmpty()) {
                        Text("Paste a YouTube link", style = Type.Body, color = Ink.Faint)
                    }
                    inner()
                }
            }
        )
        if (value.isBlank()) {
            IconButton(onClick = onPaste, enabled = enabled) {
                Icon(
                    painter = painterResource(R.drawable.ic_paste),
                    contentDescription = "Paste",
                    tint = Ink.Dust,
                    modifier = Modifier.size(22.dp)
                )
            }
        } else {
            TextButton(onClick = onAdd, enabled = enabled) {
                Text("Add", style = Type.Strong, color = Ink.Signal)
            }
        }
    }
}

private enum class Kind(val label: String, val color: Color) {
    Video("Video", Ink.Signal),
    Playlist("Playlist", Ink.Tape),
    Channel("Channel", Ink.Rose)
}

private val channelPattern = Regex("youtube\\.com/(@|channel/|c/|user/)")

private fun kindOf(url: String): Kind = when {
    url.contains("list=") -> Kind.Playlist
    channelPattern.containsMatchIn(url) -> Kind.Channel
    else -> Kind.Video
}

private fun pretty(url: String): String =
    url.removePrefix("https://").removePrefix("http://")
        .removePrefix("www.").removePrefix("m.")
        .replace(Regex("[?&]si=[^&]*"), "")
        .removeSuffix("?")

/** A queued link, drawn like the spine of a tape: the colored edge says what kind of link it is. */
@Composable
private fun SpineRow(
    item: QueueItem,
    locked: Boolean,
    onExtras: (Boolean) -> Unit,
    onRemove: () -> Unit,
    modifier: Modifier = Modifier
) {
    val kind = kindOf(item.url)
    Row(
        modifier = modifier
            .padding(top = 8.dp)
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .clip(RoundedCornerShape(6.dp))
            .background(Ink.Deck),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .width(5.dp)
                .fillMaxHeight()
                .background(kind.color)
        )
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 8.dp)
        ) {
            Text(kind.label, style = Type.Tiny, color = kind.color)
            Text(
                pretty(item.url),
                style = Type.Body,
                color = Ink.Label,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        ExtrasChip(on = item.extras, enabled = !locked, onToggle = { onExtras(!item.extras) })
        IconButton(onClick = onRemove, enabled = !locked) {
            Icon(
                Icons.Filled.Close,
                contentDescription = "Remove",
                tint = if (locked) Ink.Seam else Ink.Faint,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun ExtrasChip(on: Boolean, enabled: Boolean, onToggle: () -> Unit) {
    val shape = RoundedCornerShape(50)
    val fill by animateColorAsState(if (on) Ink.SignalDeep else Color.Transparent, tween(200), label = "fill")
    val edge by animateColorAsState(if (on) Ink.Signal else Ink.Seam, tween(200), label = "chipEdge")
    val ink by animateColorAsState(if (on) Ink.Signal else Ink.Dust, tween(200), label = "chipInk")
    Box(
        modifier = Modifier
            .clip(shape)
            .background(fill)
            .border(1.dp, edge, shape)
            .clickable(enabled = enabled, onClick = onToggle)
            .padding(horizontal = 11.dp, vertical = 6.dp)
    ) {
        Text("Extras", style = Type.Tiny, color = ink)
    }
}

@Composable
private fun Segment(
    label: String,
    selected: Boolean,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val fill by animateColorAsState(if (selected) Ink.Groove else Color.Transparent, tween(220), label = "segment")
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(9.dp))
            .background(fill)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            style = if (selected) Type.Strong else Type.Body,
            color = if (selected) Ink.Label else Ink.Dust
        )
    }
}

@Composable
private fun SaveRow(onOpen: () -> Unit) {
    Row(
        modifier = Modifier
            .padding(top = 10.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Ink.Deck)
            .clickable(onClick = onOpen)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_folder),
            contentDescription = null,
            tint = Ink.Dust,
            modifier = Modifier.size(20.dp)
        )
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(start = 14.dp)
        ) {
            Text("Saves to", style = Type.Tiny, color = Ink.Faint)
            Text("Download/OffTheReel", style = Type.Body, color = Ink.Label)
        }
        Text("Open", style = Type.Strong, color = Ink.Signal)
    }
}

@Composable
private fun Details(open: Boolean, logVersion: Int, onToggle: () -> Unit) {
    Column(
        modifier = Modifier
            .padding(top = 20.dp)
            .fillMaxWidth()
    ) {
        Text(
            text = if (open) "Hide details" else "Show details",
            style = Type.Small,
            color = Ink.Dust,
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .clickable(onClick = onToggle)
                .padding(horizontal = 4.dp, vertical = 8.dp)
        )
        AnimatedVisibility(
            visible = open,
            enter = expandVertically(tween(260)) + fadeIn(tween(200)),
            exit = shrinkVertically(tween(220)) + fadeOut(tween(150))
        ) {
            Column {
                val logText = remember(logVersion) { Engine.logText() }
                val vertical = rememberScrollState()
                val horizontal = rememberScrollState()
                LaunchedEffect(logText) {
                    withFrameNanos { }
                    vertical.scrollTo(vertical.maxValue)
                }
                Box(
                    modifier = Modifier
                        .padding(top = 4.dp)
                        .fillMaxWidth()
                        .height(260.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Ink.Deck)
                        .verticalScroll(vertical)
                        .horizontalScroll(horizontal)
                        .padding(12.dp)
                ) {
                    Text(
                        text = logText.ifEmpty { "Nothing yet." },
                        style = Type.Log,
                        color = Ink.Dust,
                        softWrap = false
                    )
                }
                Text(
                    "Made by Roki Rodriguez on October 31st, 2026",
                    style = Type.Tiny,
                    color = Ink.Faint,
                    modifier = Modifier.padding(top = 12.dp, start = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun SettingsDialog(onClose: () -> Unit) {
    var extras by remember { mutableStateOf(Engine.extrasDefault) }
    fun update(value: Boolean) {
        extras = value
        Engine.extrasDefault = value
    }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Ink.Deck,
        title = { Text("Settings", color = Ink.Label) },
        text = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { update(!extras) }
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 12.dp)
                ) {
                    Text("Extras on new links", style = Type.Strong, color = Ink.Label)
                    Text("Thumbnail, description and subtitles", style = Type.Small, color = Ink.Dust)
                }
                Switch(
                    checked = extras,
                    onCheckedChange = { update(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Ink.Oxide,
                        checkedTrackColor = Ink.Signal,
                        uncheckedThumbColor = Ink.Dust,
                        uncheckedTrackColor = Ink.Groove,
                        uncheckedBorderColor = Ink.Seam
                    )
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onClose) { Text("Done", style = Type.Strong, color = Ink.Signal) }
        }
    )
}
