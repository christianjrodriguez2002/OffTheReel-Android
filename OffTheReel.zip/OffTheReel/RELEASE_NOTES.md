## OffTheReel 1.2

- Faster: single videos and Shorts start right away, with pauses kept only for playlists and channels
- Pick your video quality: Best, 4K, 1440p, 1080p, 720p or 480p. MP3s stay at the highest quality
- Copy a YouTube link, open the app, and it offers to add it
- Shorts get their own label
- Watch a channel: tap Watch on a channel link and the app checks it once a day on Wi-Fi, saving new uploads on its own
- New Library: everything you've saved, newest first, with search. Tap to play
