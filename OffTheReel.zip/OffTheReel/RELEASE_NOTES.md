## OffTheReel 1.0

First release.

- Download videos, playlists and whole channels to your phone
- Share a link straight from the YouTube app, or paste it in
- Tap the reel to start, tap again to stop; it picks up where it left off
- Video or audio only (MP3)
- Each link shows whether it's a video, playlist or channel
- Extras checkbox on each link saves the thumbnail, description and subtitles; off by default, change it in Settings
- Saves to Download/OffTheReel, sorted by channel
- Keeps downloading with the screen off
- Keeps its downloader up to date
