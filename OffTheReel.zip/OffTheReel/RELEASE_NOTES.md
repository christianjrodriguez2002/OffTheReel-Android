## OffTheReel 1.2.1

- The OffTheReel title always fits on one line, on any screen size
