## OffTheReel 1.1

- Updates itself: when a new version is out, a banner shows what's new and installs it in a couple of taps
- Check for updates any time in Settings, which also shows your version
